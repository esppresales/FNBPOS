package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 10/6/14.
 */
public class ServerBasicResponse {
    public int status;
    public String message;
}
