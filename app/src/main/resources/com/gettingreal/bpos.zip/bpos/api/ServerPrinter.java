package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 4/6/14.
 */
public class ServerPrinter {
    public String uid, name;
    public int priority, disabled;
    public String[] category_uids;
}
