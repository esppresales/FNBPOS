package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 22/7/14.
 */
public class ServerStatus {
    public int status;
}
