package com.gettingreal.bpos;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.gettingreal.bpos.api.ServerAPIClient;
import com.gettingreal.bpos.api.ServerOrder;
import com.gettingreal.bpos.api.ServerOrderItem;
import com.gettingreal.bpos.api.ServerPostOrderResponse;
import com.gettingreal.bpos.model.POSOrder;
import com.gettingreal.bpos.model.POSOrderItem;
import com.gettingreal.bpos.model.POSProduct;
import com.gettingreal.bpos.model.POSSurcharge;
import com.gettingreal.bpos.model.POSTable;
import com.squareup.picasso.Picasso;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created with IntelliJ IDEA.
 * User: ivanfoong
 * Date: 5/3/14
 * Time: 4:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckoutFragment extends Fragment implements PrintOrderTask.OnPrintOrderTaskCompleted {

    private ListView mListView;
    private View mTableNumberLayout;
    private ToggleButton mDineInButton, mTakeawayButton;
    private TextView mSubtotalTextView, mTaxTextView, mServiceChargeTextView, mTotalTextView, mServiceChargeTitleTextView, mTaxTitleTextView;
    private BigDecimal mSubtotal = BigDecimal.ZERO, mServiceChargeAmount = BigDecimal.ZERO, mTaxAmount = BigDecimal.ZERO, mTotalAmount = BigDecimal.ZERO;
    private Spinner mTableNumberSpinner;
    private boolean isTakeAway = false;
    private ArrayList<POSTable> mPOSTables;
    private TableNumberAdapter mTableNumberAdapter;
    private Picasso mPicasso;

    private BroadcastReceiver mCheckoutBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("info", "Received cart-updated broadcast");
            updateCart();
        }
    };

    private boolean mIsServerOnline = false;
    private BroadcastReceiver mServerStatusBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("info", "Received server-status broadcast");
            mIsServerOnline = intent.getBooleanExtra("online", false);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_checkout, container, false);

        mListView = (ListView) view.findViewById(R.id.listView);
        mSubtotalTextView = (TextView) view.findViewById(R.id.txt_subtotal_amount);
        mTaxTextView = (TextView) view.findViewById(R.id.txt_tax_amount);
        mServiceChargeTextView = (TextView) view.findViewById(R.id.txt_service_charge_amount);
        mTotalTextView = (TextView) view.findViewById(R.id.txt_total_amount);
        mServiceChargeTitleTextView = (TextView)view.findViewById(R.id.txt_service_charge_title);
        mTaxTitleTextView = (TextView)view.findViewById(R.id.txt_tax_amount_title);

        // TODO: fix this hack to use priority to identify surcharge percentage
        for (POSSurcharge surcharge : POSSurcharge.getAllSurcharges(view.getContext())) {
            if (surcharge.getPriority() == 1) {
                mServiceChargeTitleTextView.setText("Svc Charge (" + String.format("%.0f", surcharge.getPercentage()) + "%)");
            }
            else if (surcharge.getPriority() == 2) {
                mTaxTitleTextView.setText("GST (" + String.format("%.0f", surcharge.getPercentage()) + "%)");
            }
        }

//        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//
//            @Override
//            public void onItemClick(AdapterView<?> parent, final View view,
//                                    int position, long id) {
//                final String item = (String) parent.getItemAtPosition(position);
//                view.animate().setDuration(2000).alpha(0)
//                        .withEndAction(new Runnable() {
//                            @Override
//                            public void run() {
//                                list.remove(item);
//                                adapter.notifyDataSetChanged();
//                                view.setAlpha(1);
//                            }
//                        });
//            }
//
//        });

        mTableNumberLayout = view.findViewById(R.id.layout_table_number);

        Button confirmOrderButton = (Button) view.findViewById(R.id.btn_confirm_order);
        confirmOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View aView) {
                confirmOrder(aView);
            }
        });

        mDineInButton = (ToggleButton) view.findViewById(R.id.btn_dine_in);
        mDineInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View aView) {
                dineIn();
            }
        });

        mTakeawayButton = (ToggleButton) view.findViewById(R.id.btn_takeaway);
        mTakeawayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View aView) {
                takeaway();
            }
        });

        mTableNumberSpinner = (Spinner) view.findViewById(R.id.spn_table_number);

        mPicasso = ((MyApplication)getActivity().getApplication()).getPicasso();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        // Register mMessageReceiver to receive messages.
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mCheckoutBroadcastReceiver,
            new IntentFilter("checkout"));
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mServerStatusBroadcastReceiver,
                new IntentFilter("server-status"));

        mPOSTables = POSTable.getAllTables(getActivity());
        mTableNumberAdapter = new TableNumberAdapter(getActivity(), mPOSTables);
        mTableNumberSpinner.setAdapter(mTableNumberAdapter);

        updateCart();
    }

    @Override
    public void onPause() {
        // Unregister since the activity is not visible
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mCheckoutBroadcastReceiver);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mServerStatusBroadcastReceiver);
        super.onPause();
    }

    private void saveTableNumberSelection(final Context aContext) {
        final int tableNumberSpinnerSelectedIndex = mTableNumberSpinner.getSelectedItemPosition();
        if (tableNumberSpinnerSelectedIndex > 0) {
            POSTable selectedPOSTable = (POSTable) mTableNumberAdapter.getItem(tableNumberSpinnerSelectedIndex);
            SettingHelper.setLastTableUid(aContext, selectedPOSTable.getUid());
        } else {
            SettingHelper.removeLastTableUid(aContext);
        }
    }

    private void updateCart() {
        final String lastTableUid = SettingHelper.getLastTableUid(getActivity());
        if (lastTableUid != null) {
            dineIn();

            for (int i = 1; i < mTableNumberAdapter.getCount(); i++) {
                POSTable POSTable = (POSTable) mTableNumberAdapter.getItem(i);
                if (POSTable.getUid().contentEquals(lastTableUid)) {
                    mTableNumberSpinner.setSelection(i);
                    break;
                }
            }
        } else {
            takeaway();
        }

        ArrayList<POSOrderItem> orderItems = POSOrderItem.getPendingOrderItems(getActivity());
        final OrderItemAdapter adapter = new OrderItemAdapter(getActivity(), orderItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mListView.setAdapter(adapter);

        mSubtotal = BigDecimal.ZERO;
        for (POSOrderItem orderItem : orderItems) {
            POSProduct product = POSProduct.getProduct(getActivity(), orderItem.getProductUid());
            if (product != null) {
                mSubtotal = mSubtotal.add(BigDecimal.valueOf(product.getPrice()).multiply(BigDecimal.valueOf(orderItem.getQuantityOrdered())));
            }
        }
        mSubtotalTextView.setText(String.format("%.2f", mSubtotal));

        // TODO: fix this hack to use priority to identify surcharge percentage
        for (POSSurcharge surcharge : POSSurcharge.getAllSurcharges(getActivity())) {
            if (surcharge.getPriority() == 1) {
                mServiceChargeAmount = mSubtotal.multiply(BigDecimal.valueOf(surcharge.getPercentage()).divide(BigDecimal.valueOf(100.0)));
                mServiceChargeTextView.setText(String.format("%.2f", mServiceChargeAmount));
            }
            else if (surcharge.getPriority() == 2) {
                mTaxAmount = mSubtotal.add(mServiceChargeAmount).multiply(BigDecimal.valueOf(surcharge.getPercentage()).divide(BigDecimal.valueOf(100.0)));
                mTaxTextView.setText(String.format("%.2f", mTaxAmount));
            }
        }

        mTotalAmount = mSubtotal.add(mServiceChargeAmount).add(mTaxAmount);
        mTotalTextView.setText(String.format("%.2f", mTotalAmount));
    }

    public void confirmOrder(View v) {
        if (mIsServerOnline) {
            saveTableNumberSelection(v.getContext());

            // validate if table number is selected for dine-in
            if (!isTakeAway) {
                if (mTableNumberSpinner.getSelectedItemPosition() == 0) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
                    alertDialogBuilder
                            .setMessage("Table Number is required for Dine-In checkout")
                            .setCancelable(false)
                            .setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    mTableNumberSpinner.requestFocus();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();
                } else {
                    SharedPreferences settings = getActivity().getSharedPreferences(getActivity().getPackageName(), 0);
                    String address = settings.getString("address", "192.168.192.168");

                    String serverUrl = "http://" + address + "/";

                    ServerAPIClient serverAPIClient = new ServerAPIClient(serverUrl);

                    final POSOrder order = createOrder();

                    ServerOrder serverOrder = new ServerOrder();
                    serverOrder.table_uid = order.getTableUid();
                    serverOrder.receipt_id = order.getReceiptId();
                    serverOrder.ordering_mode = POSOrder.getOrderingModeValue(order.getOrderingMode());
                    serverOrder.order_at = order.getOrderAt();

                    ArrayList<POSOrderItem> posOrderItems = order.getOrderItems();
                    serverOrder.order_items = new ServerOrderItem[posOrderItems.size()];
                    for (int i = 0; i < posOrderItems.size(); i++) {
                        POSOrderItem posOrderItem = posOrderItems.get(i);

                        ServerOrderItem orderItem = new ServerOrderItem();
                        orderItem.product_uid = posOrderItem.getProductUid();
                        orderItem.quantity_ordered = posOrderItem.getQuantityOrdered();
                        orderItem.quantity_served = posOrderItem.getQuantityServed();
                        orderItem.remark = posOrderItem.getRemark();

                        serverOrder.order_items[i] = orderItem;
                    }

                    serverAPIClient.createOrder(serverOrder, new Callback<ServerPostOrderResponse>() {
                        @Override
                        public void success(final ServerPostOrderResponse aServerPostOrderResponse, final Response aResponse) {
                            POSOrder.clearOrders(getActivity());
                            POSOrderItem.clearOrderItems(getActivity());

                            for (int i = 0; i < aServerPostOrderResponse.orders.length; i++) {
                                ServerOrder serverOrder = aServerPostOrderResponse.orders[i];
                                ArrayList<POSOrderItem> orderItems = new ArrayList<POSOrderItem>();
                                for (int k = 0; k < serverOrder.order_items.length; k++) {
                                    ServerOrderItem serverOrderItem = serverOrder.order_items[k];
                                    POSOrderItem orderItem = new POSOrderItem(serverOrderItem.order_id, serverOrderItem.product_uid, serverOrderItem.quantity_ordered, serverOrderItem.quantity_served);
                                    orderItem.setRemark(serverOrderItem.remark);
                                    orderItems.add(orderItem);
                                }

                                POSOrder order = new POSOrder(serverOrder.id, serverOrder.table_uid, serverOrder.receipt_id, serverOrder.order_at, POSOrder.getOrderingMode(serverOrder.ordering_mode), orderItems);
                                printOrder(order);
                            }
                        }

                        @Override
                        public void failure(final RetrofitError aRetrofitError) {
                            aRetrofitError.printStackTrace();
                        }
                    });
                }
            } else {
                SharedPreferences settings = getActivity().getSharedPreferences(getActivity().getPackageName(), 0);
                String address = settings.getString("address", "192.168.192.168");

                String serverUrl = "http://" + address + "/";

                ServerAPIClient serverAPIClient = new ServerAPIClient(serverUrl);

                final POSOrder order = createOrder();

                ServerOrder serverOrder = new ServerOrder();
                serverOrder.table_uid = order.getTableUid();
                serverOrder.receipt_id = order.getReceiptId();
                serverOrder.ordering_mode = POSOrder.getOrderingModeValue(order.getOrderingMode());
                serverOrder.order_at = order.getOrderAt();

                ArrayList<POSOrderItem> posOrderItems = order.getOrderItems();
                serverOrder.order_items = new ServerOrderItem[posOrderItems.size()];
                for (int i = 0; i < posOrderItems.size(); i++) {
                    POSOrderItem posOrderItem = posOrderItems.get(i);

                    ServerOrderItem orderItem = new ServerOrderItem();
                    orderItem.product_uid = posOrderItem.getProductUid();
                    orderItem.quantity_ordered = posOrderItem.getQuantityOrdered();
                    orderItem.quantity_served = posOrderItem.getQuantityServed();
                    orderItem.remark = posOrderItem.getRemark();

                    serverOrder.order_items[i] = orderItem;
                }

                serverAPIClient.createOrder(serverOrder, new Callback<ServerPostOrderResponse>() {
                    @Override
                    public void success(final ServerPostOrderResponse aServerPostOrderResponse, final Response aResponse) {
                        POSOrder.clearOrders(getActivity());
                        POSOrderItem.clearOrderItems(getActivity());

                        for (int i = 0; i < aServerPostOrderResponse.orders.length; i++) {
                            ServerOrder serverOrder = aServerPostOrderResponse.orders[i];
                            ArrayList<POSOrderItem> orderItems = new ArrayList<POSOrderItem>();
                            for (int k = 0; k < serverOrder.order_items.length; k++) {
                                ServerOrderItem serverOrderItem = serverOrder.order_items[k];
                                POSOrderItem orderItem = new POSOrderItem(serverOrderItem.order_id, serverOrderItem.product_uid, serverOrderItem.quantity_ordered, serverOrderItem.quantity_served);
                                orderItem.setRemark(serverOrderItem.remark);
                                orderItems.add(orderItem);
                            }

                            POSOrder order = new POSOrder(serverOrder.id, serverOrder.table_uid, serverOrder.receipt_id, serverOrder.order_at, POSOrder.getOrderingMode(serverOrder.ordering_mode), orderItems);
                            printOrder(order);
                        }
                    }

                    @Override
                    public void failure(final RetrofitError aRetrofitError) {
                        aRetrofitError.printStackTrace();
                    }
                });
            }
        }
        else {
            new AlertDialog.Builder(getActivity())
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setTitle("Unable to send order")
                    .setMessage("Service is not online")
                    .setNegativeButton("Dismiss", null)
                    .show();
        }
    }

    public void dineIn() {
        isTakeAway = false;
        mDineInButton.setChecked(true);
        mTakeawayButton.setChecked(false);
        mTableNumberLayout.setVisibility(View.VISIBLE);
    }

    public void takeaway() {
        isTakeAway = true;
        mDineInButton.setChecked(false);
        mTakeawayButton.setChecked(true);
        mTableNumberLayout.setVisibility(View.GONE);
    }

    private POSOrder createOrder() {
        ArrayList<POSOrderItem> orderItems = POSOrderItem.getPendingOrderItems(getActivity());
        if (isTakeAway == false && mTableNumberSpinner.getSelectedItemPosition() > 0) {
            POSTable selectedPOSTable = mPOSTables.get(mTableNumberSpinner.getSelectedItemPosition() - 1);
            return POSOrder.createOrder(getActivity(), Calendar.getInstance().getTime(), selectedPOSTable.getUid(), isTakeAway ? POSOrder.OrderingMode.TAKE_AWAY : POSOrder.OrderingMode.DINE_IN, orderItems);
        } else {
            return POSOrder.createOrder(getActivity(), Calendar.getInstance().getTime(), null, isTakeAway ? POSOrder.OrderingMode.TAKE_AWAY : POSOrder.OrderingMode.DINE_IN, orderItems);
        }
    }

    public void printOrder(POSOrder aPOSOrder) {
        PrintOrderTask printOrderTask = new PrintOrderTask(getActivity(), aPOSOrder, this);
        printOrderTask.execute();
    }

    public void onPrintOrderTaskCompleted(final String errorMessage) {
        Intent intent = new Intent("cart-updated");
        LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);

        if (errorMessage != null) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
            alertDialogBuilder
                .setMessage(errorMessage)
                .setCancelable(false)
                .setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();
        } else {
            intent = new Intent("checkout-completed");
            LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent);
        }
    }

    private class OrderItemAdapter extends ArrayAdapter<POSOrderItem> {

        Context mContext;
        List<POSOrderItem> mOrderItems;

        public OrderItemAdapter(Context context, List<POSOrderItem> aPOSOrderItems) {
            super(context, R.layout.cart_item, aPOSOrderItems);
            mContext = context;
            mOrderItems = aPOSOrderItems;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View rowView = inflater.inflate(R.layout.cart_item, parent, false);
            ImageView imageView = (ImageView) rowView.findViewById(R.id.img_item);
            TextView nameTextView = (TextView) rowView.findViewById(R.id.txt_name);
            TextView priceTextView = (TextView) rowView.findViewById(R.id.txt_price);
            TextView quantityTextView = (TextView) rowView.findViewById(R.id.txt_quantity);

            POSOrderItem orderItem = mOrderItems.get(position);

            POSProduct product = POSProduct.getProduct(mContext, orderItem.getProductUid());

            if (product != null) {
                nameTextView.setText(product.getName());
                priceTextView.setText(String.format("$%.2f", product.getPrice() * orderItem.getQuantityOrdered()));

                mPicasso.load(product.getImageFile()).fit().into(imageView);
            }

            if (orderItem.getQuantityOrdered() > 1) {
                quantityTextView.setVisibility(View.VISIBLE);
                quantityTextView.setText(String.valueOf(orderItem.getQuantityOrdered()));
            } else {
                quantityTextView.setVisibility(View.INVISIBLE);
            }

            return rowView;
        }
    }

    public class TableNumberAdapter extends BaseAdapter {

        private Context mContext;
        private ArrayList<POSTable> mPOSTables;

        public TableNumberAdapter(final Context aContext, final ArrayList<POSTable> aPOSTables) {
            mContext = aContext;
            mPOSTables = aPOSTables;
        }

        @Override
        public int getCount() {
            return mPOSTables.size() + 1;
        }

        @Override
        public Object getItem(final int i) {
            if (i == 0) {
                return new Object(); // placeholder for takeaway option
            }
            return mPOSTables.get(i - 1);
        }

        @Override
        public long getItemId(final int i) {
            return i - 1;
        }

        @Override
        public View getDropDownView(final int position, final View convertView, final ViewGroup parent) {
            View view = convertView;

            if (view == null) {
                view = LayoutInflater.from(mContext).inflate(R.layout.spinner_item, null);
            }

            TextView textView = (TextView) view.findViewById(R.id.text);

            Object object = getItem(position);
            if (object instanceof POSTable) {
                POSTable POSTable = (POSTable) object;
                textView.setText(POSTable.getName());
            } else {
                textView.setText("CHOOSE TABLE NO.");
            }

            return view;
        }

        @Override
        public View getView(final int position, final View convertView, final ViewGroup parent) {
            View view = convertView;

            if (view == null) {
                view = LayoutInflater.from(mContext).inflate(R.layout.spinner_item, null);
            }

            TextView textView = (TextView) view.findViewById(R.id.text);

            Object object = getItem(position);
            if (object instanceof POSTable) {
                POSTable POSTable = (POSTable) object;
                textView.setText(POSTable.getName());
            } else {
                textView.setText("CHOOSE TABLE NO.");
            }

            return view;
        }
    }
}