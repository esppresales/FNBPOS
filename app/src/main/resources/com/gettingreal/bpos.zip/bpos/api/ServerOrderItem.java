package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 10/6/14.
 */
public class ServerOrderItem {
    public Long order_id;
    public int quantity_ordered, quantity_served;
    public String product_uid, remark;
}
