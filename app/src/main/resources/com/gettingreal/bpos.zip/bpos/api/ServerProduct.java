package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 29/5/14.
 */
public class ServerProduct {
    public String uid, name;
    public int disabled;
    public float price;
    public String[] descriptions, images, category_uids;
}
