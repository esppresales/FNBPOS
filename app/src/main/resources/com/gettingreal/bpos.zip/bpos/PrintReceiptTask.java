package com.gettingreal.bpos;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import com.gettingreal.bpos.helper.PrintHelper;
import com.gettingreal.bpos.model.POSReceipt;

/**
 * Created by ivanfoong on 3/4/14.
 */
public class PrintReceiptTask extends AsyncTask<Void, Void, Void> {

    private Activity mActivity;
    private ProgressDialog mProgressDialog;
    private String mErrorMessage = null;
    private POSReceipt mReceipt;
    private OnPrintReceiptTaskCompleted mOnPrintReceiptTaskCompleted;

    public PrintReceiptTask(final Activity aActivity, final POSReceipt aReceipt, final OnPrintReceiptTaskCompleted aOnPrintReceiptTaskCompleted) {
        mActivity = aActivity;
        mReceipt = aReceipt;
        mOnPrintReceiptTaskCompleted = aOnPrintReceiptTaskCompleted;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mProgressDialog = ProgressDialog.show(mActivity, "Processing",
            "Please wait...", true);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(final DialogInterface aDialogInterface) {
                PrintReceiptTask.this.cancel(true);
            }
        });
    }

    @Override
    protected Void doInBackground(Void... urls) {
        try {
            SharedPreferences settings = mActivity.getSharedPreferences(mActivity.getPackageName(), 0);
            String address = settings.getString("address", "192.168.192.168");

            PrintHelper.getSharedInstance().printReceipt(mActivity, address, 8009, "local_printer", mReceipt);
        } catch (Exception e) {
            e.printStackTrace();
            mErrorMessage = e.getLocalizedMessage();
        }
        return null;
    }

    protected void onPostExecute(Void result) {
        //showDialog("Downloaded " + result + " bytes");
        mProgressDialog.dismiss();

        mOnPrintReceiptTaskCompleted.onPrintReceiptTaskCompleted(mErrorMessage);
    }

    public interface OnPrintReceiptTaskCompleted {
        public void onPrintReceiptTaskCompleted(String errorMessage);
    }
}
