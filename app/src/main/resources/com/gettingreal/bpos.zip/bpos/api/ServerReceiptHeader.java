package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 20/6/14.
 */
public class ServerReceiptHeader {
    public Long id;
    public String content;
    public Integer priority;
}
