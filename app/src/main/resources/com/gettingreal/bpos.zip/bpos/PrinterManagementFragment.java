package com.gettingreal.bpos;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gettingreal.bpos.model.POSPrinter;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;

import java.util.ArrayList;

/**
 * Created by ivanfoong on 24/3/14.
 */
public class PrinterManagementFragment extends Fragment {

    ListView mPrinterListView;
    Button mAddPrinterButton;
    private PrinterListAdapter mPrinterListAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_printer_management, container, false);

        mPrinterListView = (ListView) view.findViewById(R.id.list_view_printers);

        mAddPrinterButton = (Button) view.findViewById(R.id.button_add);
        mAddPrinterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View aView) {
                Fragment fragment = new PrinterAddFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out);
                transaction.replace(R.id.layout_content, fragment);
                transaction.commit();
            }
        });

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        mPrinterListAdapter = new PrinterListAdapter(getActivity());
        mPrinterListView.setAdapter(mPrinterListAdapter);
    }

    public class PrinterListAdapter extends BaseAdapter {

        Context mContext;
        ArrayList<POSPrinter> mPrinters;

        public PrinterListAdapter(final Context aContext) {
            mContext = aContext;
            mPrinters = POSPrinter.getAllPrinters(mContext);
        }

        @Override
        public int getCount() {
            return mPrinters.size();
        }

        @Override
        public Object getItem(int i) {
            return mPrinters.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = View.inflate(mContext, R.layout.printer_item, null);

            final EditText nameEditText = (EditText) view.findViewById(R.id.edit_text_name);
            final TextView deviceIdTextView = (TextView) view.findViewById(R.id.txt_device_id);
            final Button deleteButton = (Button) view.findViewById(R.id.button_delete);
            final Button testPrintButton = (Button) view.findViewById(R.id.button_test_print);

            final POSPrinter printer = mPrinters.get(i);

            nameEditText.setText(printer.getName());
            nameEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View aView, boolean b) {
                    if (!printer.getName().contentEquals(nameEditText.getText().toString())) {
                        if (nameEditText.getText().toString().equals("")) {
                            Toast.makeText(mContext, "Category name cannot be empty", Toast.LENGTH_LONG).show();
                            nameEditText.setText(printer.getName());
                        }
                        else {
                            printer.setName(nameEditText.getText().toString());
                            printer.save(mContext);
                        }
                    }
                }
            });

            deviceIdTextView.setText(printer.getUid());

            // disable deletion of master printer
            if (printer.getUid().equals("master")) {
                deleteButton.setVisibility(View.INVISIBLE);
            } else {
                deleteButton.setVisibility(View.VISIBLE);
            }

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View aView) {
                    Toast.makeText(aView.getContext(), "Printer " + printer.getName() + " is deleted!", Toast.LENGTH_LONG).show();
                    POSPrinter.deletePrinter(aView.getContext(), printer.getUid());
                    mPrinterListAdapter = new PrinterListAdapter(getActivity());
                    mPrinterListView.setAdapter(mPrinterListAdapter);
                }
            });

            testPrintButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View aView) {
                    SharedPreferences settings = aView.getContext().getSharedPreferences(aView.getContext().getPackageName(), 0);
                    String address = settings.getString("address", "192.168.192.168");
                    new TestPrintTask(aView.getContext(), address, printer.getUid()).execute();
                }
            });

            return view;
        }
    }

    private class TestPrintTask extends AsyncTask<Void, Void, Void> {

        private Context mContext;
        private String mAddress, mDeviceId;
        private ProgressDialog mProgressDialog;

        private TestPrintTask(final Context aContext, final String aAddress, final String aDeviceId) {
            mContext = aContext;
            mAddress = aAddress;
            mDeviceId = aDeviceId;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressDialog = ProgressDialog.show(mContext, "Sending",
                "Please wait...", true);
        }

        @Override
        protected Void doInBackground(Void... urls) {
            try {
                String url = "http://" + mAddress +
                    "/cgi-bin/epos/service.cgi?devid=" + mDeviceId + "&timeout=10000";

                // Send print document
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(url);

                String req =
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
                        "<s:Body>" +
                        "<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
                        "<text lang='en' smooth='true'>Intelligent Printer&#10;</text>" +
                        "<barcode type='ean13' width='2' height='48'>201234567890</barcode>" +
                        "<feed unit='24' />" +
                        "<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>" +
                        "<cut />" +
                        "</epos-print>" +
                        "</s:Body>" +
                        "</s:Envelope>";

                StringEntity entity = new StringEntity(req, HTTP.UTF_8);
                entity.setContentType("text/xml charset=utf-8");
                httppost.setEntity(entity);

                HttpResponse response = httpclient.execute(httppost);

//            // Receive response document
//            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//            DocumentBuilder builder = factory.newDocumentBuilder();
//
//            // Parse response document(DOM)
//            Document doc = builder.parse(response.getEntity().getContent());
//            Element el = (Element) doc.getElementsByTagName("response").item(0);

//                AlertDialog.Builder dlg = new AlertDialog.Builder(getActivity());
//                dlg.setTitle("Checkout");
//                dlg.setMessage(el.getAttribute("success"));
//                dlg.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dlg , int whichbutton) {
//                        //setResult(Activity.RESULT_OK);
//                    }
//                });
//                dlg.create();
//                dlg.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result) {
            mProgressDialog.dismiss();
        }
    }
}
