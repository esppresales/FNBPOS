package com.gettingreal.bpos;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gettingreal.bpos.model.POSPrinter;

import java.util.ArrayList;

/**
 * Created by ivanfoong on 27/3/14.
 */
public class PrinterAddFragment extends Fragment {

    private Button mBackButton, mAddButton;
    private EditText mNameEditText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_printer_add, container, false);

        mBackButton = (Button) view.findViewById(R.id.button_back);
        mBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View aView) {
                Fragment fragment = new PrinterManagementFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction transaction = fm.beginTransaction();
                transaction.setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out);
                transaction.replace(R.id.layout_content, fragment);
                transaction.commit();
            }
        });

        mAddButton = (Button) view.findViewById(R.id.button_add);
        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View aView) {
                getActivity().getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

                if (mNameEditText.getText().toString().equals("")) {
                    Toast.makeText(aView.getContext(), "Printer name must not be empty!", Toast.LENGTH_LONG).show();
                }
                else {
                    final String name = mNameEditText.getText().toString();
                    final String uid = name.toLowerCase().replace(' ', '_');
                    POSPrinter newPrinter = POSPrinter.createPrinter(aView.getContext(), uid, name, 0, false, new ArrayList<String>());

                    Fragment fragment = new PrinterManagementFragment();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction transaction = fm.beginTransaction();
                    transaction.setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out);
                    transaction.replace(R.id.layout_content, fragment);
                    transaction.commit();

                    if (newPrinter != null) {
                        Toast.makeText(aView.getContext(), "Printer " + newPrinter.getName() + " added!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(aView.getContext(), "Failed to create Printer " + newPrinter.getName(), Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        mNameEditText = (EditText) view.findViewById(R.id.edit_text_name);

        return view;
    }
}