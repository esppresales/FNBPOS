package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 16/6/14.
 */
public class ServerPostOrderResponse extends ServerBasicResponse {
    public ServerOrder[] orders;
}
