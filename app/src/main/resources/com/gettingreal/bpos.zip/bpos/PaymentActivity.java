package com.gettingreal.bpos;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.gettingreal.bpos.api.ServerAPIClient;
import com.gettingreal.bpos.api.ServerOrder;
import com.gettingreal.bpos.api.ServerOrderItem;
import com.gettingreal.bpos.api.ServerPostReceiptResponse;
import com.gettingreal.bpos.api.ServerReceipt;
import com.gettingreal.bpos.helper.PaymentHelper;
import com.gettingreal.bpos.helper.ServerStatusMenuHelper;
import com.gettingreal.bpos.model.POSOrder;
import com.gettingreal.bpos.model.POSOrderItem;
import com.gettingreal.bpos.model.POSReceipt;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by ivanfoong on 17/6/14.
 */
public class PaymentActivity extends Activity implements PrintReceiptTask.OnPrintReceiptTaskCompleted {
    private TextView mTotalPayableTextView, mChangeDueTextView;
    private EditText mPaymentEditText, mDiscountDescriptionEditText, mDiscountPercentageEditText;
    private Button mMarkAsPaidButton;
    private BigDecimal mSubtotal;
    private long[] mOrderIds;

    private Menu mMenu;

    private boolean mIsServerOnline = false;
    private BroadcastReceiver mServerStatusBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("info", "Received server-status broadcast");
            mIsServerOnline = intent.getBooleanExtra("online", false);
            ServerStatusMenuHelper.updateServerStatusMenu(mMenu, mIsServerOnline);
        }
    };

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Set up the action bar to show a dropdown list.
        final ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setHomeButtonEnabled(true);

        mTotalPayableTextView = (TextView) findViewById(R.id.text_view_total_payable);
        mChangeDueTextView = (TextView) findViewById(R.id.text_view_change_due);
        mPaymentEditText = (EditText) findViewById(R.id.edit_text_payment);
        mDiscountDescriptionEditText = (EditText) findViewById(R.id.edit_text_discount_description);
        mDiscountPercentageEditText = (EditText) findViewById(R.id.edit_text_discount_percentage);
        mMarkAsPaidButton = (Button) findViewById(R.id.button_mark_as_paid);

        mPaymentEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(final TextView aTextView, final int i, final KeyEvent aKeyEvent) {
                BigDecimal cashAmount = BigDecimal.valueOf(0.0);
                try {
                    cashAmount = BigDecimal.valueOf(Double.parseDouble(mPaymentEditText.getText().toString()));
                } catch (NumberFormatException e) {
                }
                ;

                BigDecimal discountAmount = BigDecimal.ZERO;
                try {
                    BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));

                    if (discountPercentage.compareTo(BigDecimal.valueOf(100.0)) > 0) {
                        mDiscountPercentageEditText.setText("100");
                        discountPercentage = BigDecimal.valueOf(100.0);
                    }

                    discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
                } catch (NumberFormatException e) {
                }

                BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

                BigDecimal totalPayable = PaymentHelper.calculateTotalForSubTotal(aTextView.getContext(), subTotalLessDiscount);
                mTotalPayableTextView.setText(String.format("$%.2f", totalPayable.doubleValue()));

                BigDecimal changeAmount = cashAmount.subtract(totalPayable);
                String change = String.format("$%.2f", changeAmount.doubleValue());
                mChangeDueTextView.setText(change);
                return false;
            }
        });

        mDiscountPercentageEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(final TextView aTextView, final int i, final KeyEvent aKeyEvent) {
                BigDecimal cashAmount = BigDecimal.valueOf(0.0);
                try {
                    cashAmount = BigDecimal.valueOf(Double.parseDouble(mPaymentEditText.getText().toString()));
                } catch (NumberFormatException e) {
                }

                BigDecimal discountAmount = BigDecimal.ZERO;
                try {
                    BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));

                    if (discountPercentage.compareTo(BigDecimal.valueOf(100.0)) > 0) {
                        mDiscountPercentageEditText.setText("100");
                        discountPercentage = BigDecimal.valueOf(100.0);
                    }

                    discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
                } catch (NumberFormatException e) {
                }

                BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

                BigDecimal totalPayable = PaymentHelper.calculateTotalForSubTotal(aTextView.getContext(), subTotalLessDiscount);
                mTotalPayableTextView.setText(String.format("$%.2f", totalPayable.doubleValue()));

                BigDecimal changeAmount = cashAmount.subtract(totalPayable);
                String change = String.format("$%.2f", changeAmount.doubleValue());
                mChangeDueTextView.setText(change);
                return false;
            }
        });

        mDiscountPercentageEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View aView, boolean b) {
                BigDecimal cashAmount = BigDecimal.valueOf(0.0);
                try {
                    cashAmount = BigDecimal.valueOf(Double.parseDouble(mPaymentEditText.getText().toString()));
                } catch (NumberFormatException e) {
                }

                BigDecimal discountAmount = BigDecimal.ZERO;
                try {
                    BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));

                    if (discountPercentage.compareTo(BigDecimal.valueOf(100.0)) > 0) {
                        mDiscountPercentageEditText.setText("100");
                        discountPercentage = BigDecimal.valueOf(100.0);
                    }

                    discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
                } catch (NumberFormatException e) {
                }

                BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

                BigDecimal totalPayable = PaymentHelper.calculateTotalForSubTotal(aView.getContext(), subTotalLessDiscount);
                mTotalPayableTextView.setText(String.format("$%.2f", totalPayable.doubleValue()));

                BigDecimal changeAmount = cashAmount.subtract(totalPayable);
                String change = String.format("$%.2f", changeAmount.doubleValue());
                mChangeDueTextView.setText(change);
            }
        });

        mMarkAsPaidButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View aView) {
                BigDecimal cashAmount = BigDecimal.ZERO;
                try {
                    cashAmount = BigDecimal.valueOf(Double.parseDouble(mPaymentEditText.getText().toString()));
                } catch (NumberFormatException e) {
                }
                ;

                BigDecimal discountAmount = BigDecimal.ZERO;
                try {
                    BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));

                    if (discountPercentage.compareTo(BigDecimal.valueOf(100.0)) > 0) {
                        mDiscountPercentageEditText.setText("100");
                        discountPercentage = BigDecimal.valueOf(100.0);
                    }

                    discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
                } catch (NumberFormatException e) {
                }

                BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

                BigDecimal totalPayable = PaymentHelper.calculateTotalForSubTotal(aView.getContext(), subTotalLessDiscount);

                if (totalPayable.compareTo(cashAmount) <= 0) {
                    payment();
                } else {
                    Toast.makeText(PaymentActivity.this, "Cash is less than total amount payable!", Toast.LENGTH_LONG).show();
                }
            }
        });

        mSubtotal = BigDecimal.valueOf(getIntent().getDoubleExtra("subtotal", 0.0));
        mOrderIds = getIntent().getLongArrayExtra("order_ids");

        BigDecimal discountAmount = BigDecimal.ZERO;
        try {
            BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));
            discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
        } catch (NumberFormatException e) {
        }

        BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

        BigDecimal totalPayable = PaymentHelper.calculateTotalForSubTotal(this, subTotalLessDiscount);
        mTotalPayableTextView.setText(String.format("$%.2f", totalPayable.doubleValue()));

        mChangeDueTextView.setText("$0");
    }

    @Override
    protected void onResume() {
        super.onResume();

        LocalBroadcastManager.getInstance(this).registerReceiver(mServerStatusBroadcastReceiver,
                new IntentFilter("server-status"));
    }

    @Override
    protected void onPause() {
        super.onPause();

        LocalBroadcastManager.getInstance(this).unregisterReceiver(mServerStatusBroadcastReceiver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.status_activity_actions, menu);
        mMenu = menu;
        return true;
    }

    private void payment() {
        BigDecimal cashAmount = BigDecimal.valueOf(0.0);
        if (!mPaymentEditText.getText().toString().equals("")) {
            cashAmount = BigDecimal.valueOf(Double.parseDouble(mPaymentEditText.getText().toString()));
        }

        BigDecimal discountAmount = BigDecimal.valueOf(0.0);
        String discountDescription = "";
        if (!mDiscountPercentageEditText.getText().toString().equals("")) {
            BigDecimal discountPercentage = BigDecimal.valueOf(Double.parseDouble(mDiscountPercentageEditText.getText().toString()));
            discountAmount = mSubtotal.multiply(discountPercentage).divide(BigDecimal.valueOf(100.0));
            discountDescription = String.format("%s @ %f%%", mDiscountDescriptionEditText.getText().toString(), discountPercentage);
        }

        BigDecimal subTotalLessDiscount = mSubtotal.subtract(discountAmount);

        BigDecimal finalAmount = PaymentHelper.calculateTotalForSubTotal(this, subTotalLessDiscount);

        Long[] orderIds = new Long[mOrderIds.length];
        for (int i = 0; i < mOrderIds.length; i++) {
            orderIds[i] = mOrderIds[i];
        }

        ServerReceipt serverReceipt = new ServerReceipt();
        serverReceipt.paid_at = new Date();
        serverReceipt.paid_amount = cashAmount;
        serverReceipt.discount_amount = discountAmount;
        serverReceipt.discount_description = discountDescription;
        serverReceipt.final_amount = finalAmount;
        serverReceipt.order_ids = orderIds;

        SharedPreferences settings = getSharedPreferences(getPackageName(), 0);
        String address = settings.getString("address", "192.168.192.168");

        String serverUrl = "http://" + address + "/";

        ServerAPIClient serverAPIClient = new ServerAPIClient(serverUrl);
        serverAPIClient.createReceipt(serverReceipt, new Callback<ServerPostReceiptResponse>() {
            @Override
            public void success(final ServerPostReceiptResponse aServerPostReceiptResponse, final Response aResponse) {
                for (int i = 0; i < aServerPostReceiptResponse.receipts.length; i++) {
                    ServerReceipt serverReceipt = aServerPostReceiptResponse.receipts[i];

                    ArrayList<POSOrder> orders = new ArrayList<POSOrder>();

                    for (int j = 0; j < serverReceipt.orders.length; j++) {
                        ServerOrder serverOrder = serverReceipt.orders[j];

                        ArrayList<POSOrderItem> orderItems = new ArrayList<POSOrderItem>();
                        for (int k = 0; k < serverOrder.order_items.length; k++) {
                            ServerOrderItem serverOrderItem = serverOrder.order_items[k];
                            POSOrderItem orderItem = new POSOrderItem(serverOrderItem.order_id, serverOrderItem.product_uid, serverOrderItem.quantity_ordered, serverOrderItem.quantity_served);
                            orderItems.add(orderItem);
                        }

                        POSOrder order = new POSOrder(serverOrder.id, serverOrder.table_uid, serverOrder.receipt_id, serverOrder.order_at, POSOrder.getOrderingMode(serverOrder.ordering_mode), orderItems);
                        orders.add(order);
                    }

                    POSReceipt receipt = new POSReceipt(serverReceipt.id, serverReceipt.discount_description, serverReceipt.paid_amount, serverReceipt.discount_amount, serverReceipt.final_amount, serverReceipt.paid_at, orders);
                    new PrintReceiptTask(PaymentActivity.this, receipt, PaymentActivity.this).execute();
                }
            }

            @Override
            public void failure(final RetrofitError aRetrofitError) {
                aRetrofitError.printStackTrace();
            }
        });
    }

    @Override
    public void onPrintReceiptTaskCompleted(final String errorMessage) {
        if (errorMessage != null) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder
                .setMessage(errorMessage)
                .setCancelable(false)
                .setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();
        } else {
            Intent intent = new Intent("orders-invalidated");
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
            finish();
        }
    }
}
