package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 4/6/14.
 */
public class ServerCategory {
    public String uid, name;
    public int priority, disabled;
}
