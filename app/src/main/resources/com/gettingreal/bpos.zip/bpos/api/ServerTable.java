package com.gettingreal.bpos.api;

/**
 * Created by ivanfoong on 4/6/14.
 */
public class ServerTable {
    public String uid, name, status;
    public int disabled;
}
